package com.intelligrape.geolocation

class GeoPosition {
    Double longitude
    Double latitude

    GeoPosition(Double aLatitude,Double aLongitude) {
        longitude = aLongitude
        latitude = aLatitude
    }
}
